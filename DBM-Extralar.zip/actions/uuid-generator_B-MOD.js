module.exports = {
  name: 'UUID Oluşturucu',
  section: '#DBM Mods (TR Extralar)',
  meta: {
    version: '2.1.7',
    preciseCheck: false,
    author: 'Custom',
    authorUrl: 'https://www.npmjs.com/package/uuid',
    downloadURL: 'https://github.com/Beratkan15/dbm-ektralar-TR/releases/download/V1.0.0/DBM-Extralar_vPre-2.zip',
  },

  subtitle(data) {
    return `Rastgele UUID Oluştur ve Kaydet: ${data.varName}`;
  },

  variableStorage(data, varType) {
    if (parseInt(data.storage, 10) !== varType) return;
    return [data.varName, 'UUID'];
  },

  fields: ['storage', 'varName'],

  html() {
    return `
      <div style="float: left; width: 95%; padding-top: 8px;">
        <span class="dbminputlabel">UUID'yi Kaydet</span><br>
        <store-in-variable dropdownLabel="UUID'yi Şu Değişkende Sakla" selectId="storage" variableContainerId="varNameContainer" variableInputId="varName"></store-in-variable>
      </div>`;
  },

  init() {},

  async action(cache) {
    const data = cache.actions[cache.index];

    // UUID modülünü yükle
    const { v4: uuidv4 } = require('uuid');

    // UUID oluştur
    const uuid = uuidv4();

    // UUID'yi değişkende sakla
    const storage = parseInt(data.storage, 10);
    const varName = this.evalMessage(data.varName, cache);
    this.storeValue(uuid, storage, varName, cache);

    this.callNextAction(cache);
  },

  mod() {},
};
