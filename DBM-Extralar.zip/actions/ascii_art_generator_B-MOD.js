module.exports = {
  name: 'ASCII Oluşturucu',
  section: '#DBM Mods (TR Extralar)',
  meta: {
    version: '2.1.7',
    preciseCheck: false,
    author: 'Custom',
    authorUrl: 'https://patorjk.com/software/taag/',
    downloadURL: '',
  },

  subtitle(data) {
    return `Düz Yazıdan ASCII Yazıya Dönüştürücü: ${data.text}`;
  },

  variableStorage(data, varType) {
    if (parseInt(data.storage, 10) !== varType) return;
    return [data.varName, 'ASCII Art'];
  },

  fields: ['text', 'font', 'storage', 'varName'],

  html() {
    return `
  <div style="width: 95%; padding-top: 8px;">
    <span class="dbminputlabel">Düz Yazıyı ASCII Yazısına Dönüştürür</span>
    <textarea id="text" rows="3" placeholder="Yazını Buraya Yaz..." style="width: 100%; font-family: monospace; resize: none;"></textarea>
  </div><br>
  <div style="padding-top: 8px; width: 95%;">
    <span class="dbminputlabel">Font Şekli</span>
    <select id="font" class="round">
      <option value="Standard" selected>Standard</option>
      <option value="ANSI Shadow">ANSI Shadow</option>
      <option value="Big">Big</option>
      <option value="Block">Block</option>
      <option value="Doom">Doom</option>
      <option value="Banner">Banner</option>
      <!-- Diğer Font Seçeneklerini Buraya Ekleyebilirsiniz -->
    </select>
  </div><br>
  <div style="float: left; clear: both; width: 100%; padding-top: 8px;">
    <store-in-variable dropdownLabel="Store In" selectId="storage" variableContainerId="varNameContainer" variableInputId="varName"></store-in-variable>
  </div>`;
  },

  init() {},

  async action(cache) {
    const data = cache.actions[cache.index];
    const text = this.evalMessage(data.text, cache);
    const font = this.evalMessage(data.font, cache);

    if (!text) {
      console.log('ASCII Yazısına Dönüştürecek Düz Yazı Bulunamadı.');
      return this.callNextAction(cache);
    }

    // Figlet modülünü yükle
    const figlet = require('figlet');

    // ASCII sanatı oluştur
    figlet.text(text, { font: font }, (err, asciiArt) => {
      if (err) {
        console.error(`ASCII Yazısı Oluşturulurken Hata Oluştu!: ${err}`);
        return this.callNextAction(cache);
      }

      if (asciiArt) {
        const storage = parseInt(data.storage, 10);
        const varName = this.evalMessage(data.varName, cache);
        this.storeValue(asciiArt, storage, varName, cache);
      }

      this.callNextAction(cache);
    });
  },

  mod() {},
};
