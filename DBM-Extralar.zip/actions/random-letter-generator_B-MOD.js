module.exports = {
  name: 'Rastgele Harf Oluşturucu',
  section: '#DBM Mods (TR Extralar)',
  meta: {
    version: '2.1.7',
    preciseCheck: false,
    author: 'Custom',
    authorUrl: 'https://github.com/Beratkan15/dbm-ektralar-TR',
    downloadURL: 'https://github.com/Beratkan15/dbm-ektralar-TR/releases/download/V1.0.0/DBM-Extralar_vPre-2.zip',
  },

  subtitle(data) {
    return `Harf Aralığı: ${data.firstLetter} - ${data.secondLetter}, Uzunluk: ${data.length}`;
  },

  variableStorage(data, varType) {
    if (parseInt(data.storage, 10) !== varType) return;
    return [data.varName, 'String'];
  },

  fields: ['firstLetter', 'secondLetter', 'length', 'storage', 'varName'],

  html() {
    return `
      <div style="width: 95%; padding-top: 8px;">
        <span class="dbminputlabel">1. Harf</span>
        <input id="firstLetter" class="round" placeholder="Örn: A" style="width: 50%;">
        <span class="dbminputlabel" style="padding-left: 10px;">2. Harf</span>
        <input id="secondLetter" class="round" placeholder="Örn: Z" style="width: 50%;">
      </div><br>
      <div style="width: 95%; padding-top: 8px;">
        <span class="dbminputlabel">Uzunluk</span>
        <input id="length" class="round" placeholder="Örn: 5" type="number" style="width: 100%;">
      </div><br>
      <div style="float: left; clear: both; width: 100%; padding-top: 8px;">
        <store-in-variable dropdownLabel="Store In" selectId="storage" variableContainerId="varNameContainer" variableInputId="varName"></store-in-variable>
      </div>`;
  },

  init() {},

  async action(cache) {
    const data = cache.actions[cache.index];
    const firstLetter = this.evalMessage(data.firstLetter, cache);
    const secondLetter = this.evalMessage(data.secondLetter, cache);
    const length = parseInt(this.evalMessage(data.length, cache), 10);

    if (!firstLetter || !secondLetter || !length) {
      console.log('Gerekli alanları doldurunuz!');
      return this.callNextAction(cache);
    }

    // Belirtilen harf aralığındaki harfleri bir diziye aktar
    const startCode = firstLetter.toUpperCase().charCodeAt(0);
    const endCode = secondLetter.toUpperCase().charCodeAt(0);
    let characters = [];

    for (let i = startCode; i <= endCode; i++) {
      characters.push(String.fromCharCode(i));
    }

    // Rastgele harflerden oluşan sonucu üret
    let result = '';
    while (result.length < length) {
      const randomIndex = Math.floor(Math.random() * characters.length);
      const randomChar = characters[randomIndex];
      if (!result.includes(randomChar)) {
        result += randomChar;
      }
    }

    const storage = parseInt(data.storage, 10);
    const varName = this.evalMessage(data.varName, cache);
    this.storeValue(result, storage, varName, cache);

    this.callNextAction(cache);
  },

  mod() {},
};
