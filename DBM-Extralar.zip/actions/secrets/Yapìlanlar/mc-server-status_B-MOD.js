module.exports = {
  name: 'Sunucu Oyuncu Sayısını Göster',
  section: '#DBM Mods (TR Extralar)',
  meta: {
    version: '2.1.7',
    preciseCheck: false,
    author: 'Custom',
    authorUrl: 'https://yourwebsite.com',
    downloadURL: 'https://github.com/username/repo/archive/main.zip',
  },

  subtitle(data) {
    return `Sunucu IP: ${data.serverIP}`;
  },

  variableStorage(data, varType) {
    if (parseInt(data.storage, 10) !== varType) return;
    return [data.varName, 'String'];
  },

  fields: ['serverIP', 'storage', 'varName'],

  html() {
    return `
      <div style="width: 95%; padding-top: 8px;">
        <span class="dbminputlabel">Sunucu IP</span>
        <input id="serverIP" class="round" type="text" placeholder="Sunucu IP adresini girin...">
      </div><br>
      <div style="float: left; clear: both; width: 100%; padding-top: 8px;">
        <store-in-variable dropdownLabel="Store In" selectId="storage" variableContainerId="varNameContainer" variableInputId="varName"></store-in-variable>
      </div>`;
  },

  init() {},

  async action(cache) {
    const data = cache.actions[cache.index];
    const serverIP = this.evalMessage(data.serverIP, cache);

    if (!serverIP) {
      console.log('Sunucu IP adresi girilmedi!');
      return this.callNextAction(cache);
    }

    const Gamedig = require('gamedig');

    try {
      const state = await Gamedig.query({
        type: 'minecraft', // Oyun türünü belirtin
        host: serverIP,
      });

      const serverName = state.name || 'Bilinmeyen Sunucu'; // Sunucu adı yoksa varsayılan değeri kullan
      const playerCount = state.players?.length ?? 0; // Oyuncu sayısını al, yoksa 0 olarak ata
      const maxPlayers = state.maxplayers ?? 'Bilinmiyor'; // Maksimum oyuncu sayısı yoksa varsayılan değer kullan

      const result = `${serverName} : ${playerCount}/${maxPlayers} Oyuncu Var`;

      const storage = parseInt(data.storage, 10);
      const varName = this.evalMessage(data.varName, cache);
      this.storeValue(result, storage, varName, cache);

      this.callNextAction(cache);
    } catch (error) {
      console.error('Sunucu bilgileri alınırken hata oluştu:', error);
      const storage = parseInt(data.storage, 10);
      const varName = this.evalMessage(data.varName, cache);
      this.storeValue('Sunucu bilgisi alınamadı.', storage, varName, cache); // Hata durumunda mesaj sakla
      this.callNextAction(cache);
    }
  },

  mod() {},
};
